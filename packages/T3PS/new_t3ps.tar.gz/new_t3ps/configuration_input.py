#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 16:16:23 2022

@author: cb27g11
"""

# ----------------------------------------------------------------------------#
# | [D.06] Configuration Input (Parameter Range, Formulas and Preprocessing) |#
# ----------------------------------------------------------------------------#


#  Functions to handle configuration input files for t3ps. Originally written by Vinzenz Maurer.

def find_file(path, base_dir):
    """Find file specified by path.

    It is searched relative to either:
        current folder (1st try)
        base_dir (2nd try)
        or the directory of the running executable (3rd try)
        or the directory of the running executable (if sym link) (3'rd try)
        or relative to the current directory (4th try)

    This always returns an absolute path.
    """
    print "---------------inside find_file---------------"
    path = os.path.expanduser(path)
    if os.path.isabs(path):
        return path

    candidate = os.path.abspath(path)
    if os.path.isfile(candidate):
        return candidate

    candidate = os.path.abspath(os.path.join(base_dir, path))
    if os.path.isfile(candidate):
        return candidate

    candidate = os.path.abspath(os.path.join(os.path.dirname(__file__), path))
    if os.path.isfile(candidate):
        return candidate

    if os.path.islink(__file__):
        candidate = os.path.abspath(
            os.path.join(
                os.path.dirname(os.path.realpath(__file__)),
                path
            )
        )
        if os.path.isfile(candidate):
            return candidate

    return os.path.abspath(path)


def find_in_path(program):
    """Find executable in PATH environment variable."""
    print "-----------inside find_in_path-----------------"
    for path in os.environ["PATH"].split(os.pathsep):
        path = path.strip('"')
        print "path after stripping is: ", path
        if path == ".":
            continue  # ignore "." in PATH since it is not constant
        exe_file = os.path.join(path, program)
        print "exe_file is given by : ", exe_file
        if os.path.exists(exe_file):
            return exe_file

    return None


def find_binary_file(binary_path, base_dir):
    """Find executable file.

    First tries finding it in PATH environment variable, else uses
    find_file function
    """
    print "inside 'find_binary_file' looking for executable"
    print( 'binary_path' , binary_path)
    # searching through PATH is only necessary for paths that are just names
    if not os.path.isabs(binary_path) and os.path.dirname(binary_path) == "":
        candidate = find_in_path(binary_path)
        print('candiate' , candidate)
        if candidate is not None and os.path.isfile(candidate):
            return candidate

    return find_file(binary_path, base_dir)


def PreprocessedConfigFile(file_name, short_name=None, base_dir=None,
                           depth=0, max_depth=10):
    """Return file-like object with @include statements processed."""
    # base_dir is only supposed to be None on the depth = 0 file
    # print "                        "
    # print 'inside PreprocessedConfigFile '
    # print "                         "
    if base_dir is None:
        base_dir = os.path.dirname(find_file(file_name, "."))
        print( 'base_dir' , base_dir)

    # likewise short_name
    if short_name is None:
        short_name = file_name

    contents = StringIO.StringIO()
    # if not depth:
    #     contents.write("[DEFAULT]\n")
    lineno = 0
    real_locations = []
    has_includes = False
    with open(file_name) as f:
        for line in f:
            lineno += 1
            # format of include lines: "@include" WHITESPACE FILENAME
            if line.startswith("@include"):
                has_includes = True
                if depth + 1 > max_depth:
                    e = ConfigParser.ParsingError(file_name)
                    e.append(
                        lineno,
                        "maximal include depth exceeded: %i" % (depth + 1)
                    )
                    raise e

                # strip the trailing "\n" and split into the one "@include"
                #   and the rest of the line with arbitrary whitespace after
                #   the "@include"
                other_filename = line.rstrip("\n").split(None, 1)[-1]
                print( ' other_filename ' , other_filename)
                full_name = find_file(other_filename, base_dir)

                other_file = PreprocessedConfigFile(
                    full_name,
                    short_name=other_filename,
                    base_dir=base_dir,
                    depth=depth + 1
                )
                print( 'other_file', other_file)
                real_locations.extend(other_file.real_locations)
                for line in other_file:
                    contents.write(line)

                # make sure the next line in the including file starts normally
                if not other_file.getvalue().endswith("\n"):
                    contents.write("\n")

            else:
                real_locations.append((lineno, short_name))
                contents.write(line)

    # context support: translate ConfigParser error if appropriate
    setattr(contents, "__enter__", lambda contents=contents: contents)

    def exit_preproc_context(exc_type, exc_value, _tb, contents=contents):
        contents.close()
        if exc_type == ConfigParser.ParsingError:
            raise contents.translate_error(exc_value)
    setattr(contents, "__exit__", exit_preproc_context)

    # setup the real locations info
    # error translation is only necessary if includes happened
    setattr(contents, "real_locations", real_locations)
    if has_includes:
        def translate_error(e, self=contents):
            # ParsingError.errors has format: [(lineno, text), ...]
            e.message = e.message.splitlines()[0]
            for error_data in e.errors:
                e.message += '\n\t[line %i in %s]: %s' % (
                    self.real_locations[error_data[0] - 1][0],
                    self.real_locations[error_data[0] - 1][1],
                    error_data[1]
                )

            return e
        contents.translate_error = translate_error
    else:
        contents.translate_error = lambda e: e

    contents.seek(0)
    return contents

ParameterRange_Interval = namedtuple(
    "ParameterRange_Interval", ["start", "end"]
)
ParameterRange_NormalVariate = namedtuple(
    "ParameterRange_NormalVariate", ["mu", "sigma"]
)

class ParameterRange(object):

    """Class used to convey information on parameter ranges.

    They can be given in the following form:
        * discrete/finite ranges: "a, b, c" and so on, or "a, b, ..., c"
            (meaning the ellipsis is substituted like "a, b, a+2(b-a), ..., c"
            these can also be concatenated, e.g. "1, 2, ..., 10, 20, ..., 100"
                -> (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70,
                    80, 90, 100)
            alternative syntax: "finite(a, b, ... c)" etc.
        * continuous ranges:
            * on an interval:
                "interval(a, b) with [count=<n>,] [distribution=<log|linear>]
                if count is given, the range will automatically be converted
                    to a finite range with spacing according to distribution
                    (default:linear)
            * following normal distribution:
                "normalvariate(mu, sigma) with [count=<n>]"
                similarly to interval, specifying count makes the range
                    finite while preserving its distribution as sample

        options and type names are case-insensitive
    This class uses decimal internally, but all exposed values are float.
    """

    def __init__(self, s):
        """Initialize parameter range with definition."""
        if not isinstance(s, basestring):
            raise ValueError(
                "invalid parameter range definition type: " + str(type(s))
            )
        if not s:
            raise ValueError("empty parameter range")
        parts = s.split("with")
        if len(parts) > 2:
            raise ValueError("too many option parts: " + s)

        range_def, options = map(str.strip, (parts + [""])[0:2])
        if not range_def:
            raise ValueError("empty definition: " + s)

        try:
            self._options = dict()
            for k_v in options.split(","):
                if k_v:
                    k, v = (map(str.strip, k_v.split("=")) + [""])[0:2]
                    # Convert with .lower() for case-insensitivity
                    self._options[k.lower()] = maybedecimal(v)
        except Exception as e:
            raise ValueError("error parameter range options: " + str(e))

        if range_def[0] in string.ascii_letters:
            iterator = iter(range_def)
            # Convert with .lower() for case-insensitivity
            type_name = ''.join(
                itertools.takewhile(lambda x: x != "(", iterator)
            ).lower()
            definition = ''.join(
                itertools.takewhile(lambda x: x != ")", iterator)
            )
            garbage = ''.join(iterator)
            if garbage:
                raise ValueError(
                    "unexpected part in range definition: " + garbage
                )
        else:
            type_name = "finite"
            definition = range_def

        if type_name == "interval":
            self._type = "interval"
            if "distribution" not in self._options:
                self._options["distribution"] = "linear"

            parts = definition.split(",")
            if len(parts) != 2:
                raise ValueError("invalid interval definition: " + definition)
            try:
                start, end = map(Decimal, parts)
                if start == end:
                    raise ValueError("zero interval length")
                if start > end:
                    raise ValueError("negative interval length")
                self._definition = "interval(%s, %s)" % (start, end)
            except (ValueError, decimal.InvalidOperation) as e:
                raise ValueError("invalid interval bounds: " + str(e))

            dist = self._options.get("distribution", "linear")
            if dist not in ["linear", "log"]:
                raise ValueError("unsupported distribution: " + str(dist))

            if dist == "log" and start <= 0 or end <= 0:
                raise ValueError(
                    "invalid bounds for log distribution: %s, %s" % (
                        start, end
                    )
                )

            if "count" not in self._options:
                self._data = ParameterRange_Interval(
                    start=float(start), end=float(end)
                )
            else:
                self._type = "finite"
                count = int(self._options["count"])
                if count < 2:
                    raise ValueError("point count too small: " + str(count))

                if dist == "linear":
                    self._data = []
                    delta = (end - start) / (count - 1)

                    for i in xrange(count - 1):
                        self._data.append(start + i * delta)
                    # add end by hand instead of calculating it due to
                    #   rounding errors
                    self._data.append(end)

                elif dist == "log":
                    self._data = []

                    delta = (end / start) ** (1 / Decimal(count - 1))
                    for i in xrange(count - 1):
                        self._data.append(start * (delta ** i))
                    # some numerical errors always creep in, so add the end
                    #   by hand and not by calculation
                    self._data.append(end)

        elif type_name == "normalvariate":
            self._type = "normalvariate"
            parts = definition.split(",")
            if len(parts) != 2:
                raise ValueError("invalid interval definition: " + definition)
            try:
                mu, sigma = map(Decimal, parts)
                if sigma <= 0:
                    raise ValueError("non-positive standard deviation")
                self._data = ParameterRange_NormalVariate(
                    mu=float(mu), sigma=float(sigma)
                )
                self._definition = "normalvariate(%s, %s)" % (mu, sigma)
            except (ValueError, decimal.InvalidOperation) as e:
                raise ValueError("invalid normalvariate parameters: " + str(e))

            if "distribution" in self._options:
                raise ValueError(
                    "'distribution' option not supported for normalvariate"
                )

            if "count" in self._options:
                self._type = "finite"
                count = int(self._options["count"])
                if count < 1:
                    raise ValueError("point count too small: " + str(count))
                self._data = []
                delta = 1.0 / (count + 1)
                for i in xrange(count):
                    self._data.append(
                        float(mu) +
                        float(sigma) * U.inversenormalcdf(delta * (i + 1))
                    )

        elif type_name == "finite":
            self._type = "finite"
            if "distribution" in self._options:
                raise ValueError(
                    "'distribution' option not supported for finite ranges"
                )
            if "count" in self._options:
                raise ValueError(
                    "'count' option not supported for finite ranges"
                )
            parts = map(maybedecimal, map(str.strip, definition.split(",")))
            self._data = []
            self._definition = ', '.join(map(str, parts))
            for i, x in enumerate(parts):
                if x in ["..", "..."]:
                    if i - 2 < 0 or i + 1 >= len(parts) or \
                       not U.is_number(parts[i - 2]) or \
                       not U.is_number(parts[i - 1]) or \
                       not U.is_number(parts[i + 1]):
                        # any of the parts is not there or not a number
                        raise ValueError(
                            "ellipsis must be preceded by two valid numbers "
                            "and succeeded by one"
                        )
                    # range of form a, b, ... ,c
                    a, b, c = (
                        Decimal(parts[i - 2]),
                        Decimal(parts[i - 1]),
                        Decimal(parts[i + 1])
                    )
                    if a == b:
                        raise ValueError(
                            "range with step 0: %s == %s" % (a, b)
                        )
                    if not (a < b < c or a > b > c):
                        raise ValueError(
                            "unordered partial range: does not fulfill "
                            "%s < %s < %s" % (a, b, c)
                        )

                    delta = b - a
                    x = b + delta
                    while x < c:
                        self._data.append(float(x))
                        x += delta
                else:
                    try:
                        x = Decimal(x)
                    except (ValueError, decimal.InvalidOperation) as e:
                        raise ValueError("invalid range part: " + str(e))

                    self._data.append(float(x))
        else:
            raise ValueError("unsupported range type: " + type_name)

        if self._type == "finite":
            print "setting self._data  "

            self._data = map(float, self._data)
            print "self._data is ", self._data
            self._strdata = map(repr, self._data)
            print "self._strdata is ", self._strdata

        if "distribution" in self._options:
            self._options["distribution"] = str(self._options["distribution"])

        if "mcmc_stepsize" in self._options:
            self._options["mcmc_stepsize"] = float(
                self._options["mcmc_stepsize"]
            )

    def __str__(self):
        """Convert parameter range back to definition string."""
        if self._options:
            return self._definition + " with " + ', '.join(
                sorted(
                    k + "=" + str(v)
                    for k, v in self._options.iteritems()
                )
            )
        return self._definition

    def __repr__(self):
        """Return evaluable object definition."""
        return "ParameterRange(%r)" % str(self)

    @property
    def is_finite(self):
        """Return whether parameter range has only finite amount of values."""
        return isinstance(self._data, list)

    @property
    def values(self):
        """Return tuple of possible parameter values."""
        if self.is_finite:
            return tuple(self._data)
        else:
            return self._data

    @property
    def options(self):
        """Return the options used in parameter range definition."""
        return dict(self._options)

    def index(self, value):
        """Return the index of value in our list of values."""
        if isinstance(self._data, list):
            return self._strdata.index(repr(value))
        raise ValueError(
            "parameter range type '%s' is not iterable" % self._type
        )

    def truncate(self, value):
        """Truncate value to one of the possible values.

        This will be the one with the same repr representation.
        """
        if isinstance(self._data, list):
            print " checking if self._data is a list "
            print self._data[self._strdata.index(repr(value))]
            return self._data[self._strdata.index(repr(value))]
        raise ValueError(
            "parameter range type '%s' is not iterable" % self._type
        )

    def pull_inside(self, value):
        """Return number in parameter range that is nearest to given value."""
        #wtf is happening here?
        if isinstance(self._data, list):
            return min(self._data, key=lambda x: abs(x - value))
        elif isinstance(self._data, ParameterRange_NormalVariate):
            return value
        elif isinstance(self._data, ParameterRange_Interval):
            if self._data.start < self._data.end:
                return max(self._data.start, min(value, self._data.end))
            else:
                return max(self._data.end, min(value, self._data.start))

    def __nonzero__(self):
        """Return True."""
        # non-zero length parameter ranges are filtered out by __init__
        # thus parameter ranges are always considered non-zero
        return True

    def __len__(self):
        """Return number of possible values (if finite)."""
        if isinstance(self._data, list):
            return len(self._data)
        raise ValueError(
            "parameter range type '%s' has no length" % self._type
        )

    def __contains__(self, value):
        """Return whether value is member of parameter range."""
        if isinstance(self._data, list):
            # values are often converted to string and back to float
            # they should still be "inside" the values list afterwards
            return repr(value) in self._strdata
        elif isinstance(self._data, ParameterRange_NormalVariate):
            return True
        elif isinstance(self._data, ParameterRange_Interval):
            if self._data.start < self._data.end:
                return self._data.start < value < self._data.end
            else:
                return self._data.end < value < self._data.start

    def __iter__(self):
        """Return iterator over parameter range values."""
        if isinstance(self._data, list):
            return iter(self._data)
        raise ValueError("parameter range type '%s' not iterable" % self._type)


# namedtuple like class that does not care about the number of names it gets
#   the names label the first len(names) entries, the rest can only be
#   accessed by index
# NOTE: member access is only about 30% slower than in namedtuple
def flexible_record(names):
    """Return namedtuple-like object that does not care about names."""
    class _flexible_record(tuple):
        pass

    _flexible_record.__names__ = []
    for index, name in enumerate(names):
        _flexible_record.__names__.append(name)
        # add property to new record class that references indexed element
        #   by name
        setattr(
            _flexible_record,
            name,
            property(lambda self, index=index: self[index])
        )

    return _flexible_record


def check_names(names):
    """Check whether the given list yields valid names.

    That means no empty names, no duplicates, no keywords,
    no invalid characters.
    """
    names_set = set()
    identifier_chars = string.ascii_letters + string.digits + "_"
    for n in names:
        if not n:
            raise ValueError("empty name used")
        if n in names_set:
            raise ValueError("name used multiple times: %s" % n)
        if keyword.iskeyword(n):
            raise ValueError("name is keyword: %s" % n)
        if n.startswith("_") or not all(c in identifier_chars for c in n):
            raise ValueError("name contains invalid characters: %s " % n)
        names_set.add(n)
    return


class FormulaError(Exception):

    """Exception class raised in formulas by formula_eval."""

    def __str__(self):
        """Return concatenated error arguments.

        First argument is the error message.
        Second is parameter point that generated the error.
        """
        return '\n'.join(self.args)


def formula_eval(function,
                 pars=None, vars=None,
                 data=None, file=None,
                 **kwargs):
    """Compile and evaluate user supplied Python expression formulas."""
    print "Inside formula_eval!"
    print "function  ", function

    print "evaluating " + str(function)
    # Has to be called as in
    #   formula_eval(None, par_names, var_names, data_names,
    #       file_column_names)
    #   to set names   

    if not hasattr(formula_eval, "cache"):
        print "formula_eval does not contain 'cache'"
        formula_eval.cache = {}

    cache = formula_eval.cache
    if function is None:
        print "function is None "
        # cache[None] is used to store the namedtuple converter
        # arguments now specify the names for the different values
        # NOTE: names have to be valid identifiers:
        #   letters, digits, and underscores
        #   not starting with underscore
        #   no Python keyword
        cache[None] = (
            namedtuple("par_record", pars),
            namedtuple("var_record", vars),
            # data values, file columns can also be wholly unnamed if the
            #   user does not specify names
            # -> no need to use flexible record then
            flexible_record(data) if data else (lambda x: x),
            flexible_record(file) if file else (lambda x: x)
        )
        print cache
        print "cache[None][2](data)  ", cache[None][2](data)
        print "flexible_record(data)  ", flexible_record(data).__names__
        print "cache[None][3]  ", cache[None][3]


        # namedtuple will raise ValueError's if one of the names is not valid
        #   should never happen due to check_names called before this

        return

    par_record, var_record, data_record, file_record = cache[None]
    print "par_record   ", par_record
    print "var_record   ", var_record
    print "data_record   ", data_record
    print "file_record   ", file_record

    # key is code + used keyword args, such that the compiled code is uniquely
    #   determined by the call
    key = "".join([function, ":"] + kwargs.keys())
    print "key is  ", key

    if key in cache:
        cached_function = cache[key]
        print "cached_function  ", cached_function
    else:
        # replace new line chars, so the return is definitely the only
        #   executed statement
        code = "def function(pars, vars, data, file%s): return (%s)" % (
            ', ' + ', '.join(kwargs.keys()) if kwargs else '',
            function.replace("\n", " ")
        )
        namespace = math_namespace()
        #print "namespace  ", namespace
        namespace.update(formula_eval.helper_modules)
        # this inherits future division implicitly

        exec code in namespace
        cached_function = cache[key] = namespace["function"]
        print "cached_function  ", cached_function

    try:
        # only pars, vars, data and file items have names everything else is
        #   only by index or not iterable
        
        print "cached_function (stuff)  ",  cached_function(
            pars=par_record(*pars) if pars else None,
            vars=var_record(*vars) if vars else None,
            data=data_record(data) if data else None,
            file=file_record(file) if file else None,
            **kwargs
        ) 
        print " data['chi2_Tot_gfitter'] ", data[73] 
        print "data.chi2_Tot_gfitter ", data.chi2_Tot_gfitter
    
        return cached_function(
            pars=par_record(*pars) if pars else None,
            vars=var_record(*vars) if vars else None,
            data=data_record(data) if data else None,
            file=file_record(file) if file else None,
            **kwargs
        )
    except Exception as e:
        raise FormulaError(
            "Error in formula '%s': [%s] %s" % (
                function.replace("\n", " "),
                type(e).__name__,
                str(e)
            ),
            "For pars=%s, vars=%s, data=%s, file=%s%s" % (
                pars, vars, data, file,
                (
                    ", " + ", ".join(
                        k + "=" + repr(v) for k, v in kwargs.iteritems()
                    )
                ) if kwargs else ""
            )
        )



def remember(*args, **kwargs):
    if not args:
        if len(kwargs) != 1:
            raise ValueError(
                "remember called with more or less than one parameter"
            )
        remember.memory.update(kwargs)
        return kwargs.values()[0]
    if args[0] is None:
        remember.memory = {}
        return
    return remember.memory[args[0]]


def math_namespace():
    """Return dictionary containing math functions for formulas."""
    return {
        "math": math,
        "pi": math.pi,

        "cos": math.cos, "sin": math.sin, "tan": math.tan,
        "acos": math.acos, "asin": math.asin,
        "atan": math.atan, "atan2": math.atan2,

        "exp": math.exp, "log": math.log, "log10": math.log10,
        "sqrt": math.sqrt,
        "acosh": math.acosh, "asinh": math.asinh, "atanh": math.atanh,
        "cosh": math.cosh, "sinh": math.sinh, "tanh": math.tanh,
        "remember": remember
    }
