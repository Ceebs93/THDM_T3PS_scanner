#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 15:14:27 2022

@author: cb27g11
"""

# ----------------------------------- #
# |  [D.09] Explorer Mode Functions | #
# ----------------------------------- #

#  Functions for t3ps explorer mode. Originally written by Vinzenz Maurer.

def index2point(k, par_ranges):
    """Convert index into parameter space grid into coordinates.

    The parameter space grid is counted the following way:
        Let X_i = { x_ij } be the set of values for parameter i
        Then the index k of (x_{1,n_1}, x_{2,n_2}, x_{3,n_3}, ...) is
            k = n1 + |X_1| n2 + |X_1| |X_2| n3 + ...

        Then
            n_1 = k mod |X_1|
            n_2 = (k - n_1) / |X_1| mod |X_2|
            n_3 = (k - n_1 - |X_1| n_2) / (|X_2| |X_1|) mod |X_3|
            ...
    """
    # Variables:
    # n_i = ki[i - 1] (arrays start at 0)
    # k_i = (k - km) / l mod |X_i|
    #   (with km and l defined such that it matches last equations in doc str

    km = 0
    l = 1
    ki = [0] * len(par_ranges)
    for i, r in enumerate(par_ranges):
        ki[i] = int((k - km) / l % len(r))
        km += ki[i] * l
        l *= len(r)
    return tuple([r[ki[i]] for i, r in enumerate(par_ranges)])


def point2index(x, par_ranges):
    """Inverse function of index2point."""
    # Note that range(0) == [] and U.prod([]) == 1
    return sum(
        par_ranges_i.index(x[i])
        *
        U.prod([len(par_ranges[j]) for j in range(i)])
        for i, par_ranges_i in enumerate(par_ranges)
    )


def neighbors(index, par_ranges, stepsize=1):
    """Return neighbors of point.

    Neighbors defined as in:
      N
    N X N
      N
    This scales as 2*d for d dimensions
    """
    print "-----------I am inside neighbours-----------"
    result = []
    rs = [range(len(r)) for r in par_ranges]
    print "rs is: "
    print rs
    multiindex = index2point(index, rs)
    stepsize_ = int(max(math.ceil(stepsize), 1))
    for i, r in enumerate(par_ranges):
        neighbor_multiindex = list(multiindex)
        neighbor_multiindex[i] = min(multiindex[i] + stepsize_, len(r) - 1)
        if neighbor_multiindex[i] != multiindex[i]:
            result.append(tuple(neighbor_multiindex))
        neighbor_multiindex[i] = max(multiindex[i] - stepsize_, 0)
        if neighbor_multiindex[i] != multiindex[i]:
            result.append(tuple(neighbor_multiindex))
    print "I am just leaving neighbours now"
    return [point2index(n, rs) for n in result]


def extended_neighbors(index, par_ranges, stepsize=1):
    """Return extended neighbors of given point.

    Neighbors defined as in
    N N N
    N X N
    N N N

    This scales as 3^d-1 for d dimensions
    """
    rs = [range(len(r)) for r in par_ranges]
    multiindex = index2point(index, rs)
    stepsize_ = int(max(math.ceil(stepsize), 1))

    dim = len(multiindex)
    result = [
        tuple(
            [
                min(max(multiindex[i] + delta[i], 0), len(par_ranges[i]) - 1)
                for i in range(dim)
            ]
        )
        for delta in itertools.product([-stepsize_, 0, stepsize_], repeat=dim)
    ]
    result.remove(multiindex)
    return [point2index(n, rs) for n in result]


def is_boundary(index, nodes, par_ranges):
    """Check if a point lies on the boundary of the set of points in nodes.

    A point lies on the boundary if and only if:
        * it has been calculated and was valid
        * it is "likely" enough
        * one of its neighbors has not been calculated yet
    """
    index_data = nodes[index]
    # nodes[index][1] is 'maybe_boundary' field
    #   it is initially True and is set to False (only here!) when all
    #   neighbors have been calculated
    if index_data is None or not index_data[1] or \
       not index_data[0] >= min_likelihood:
        # use "not a >= b" instead of "a < b" to catch "nan"s
        return False

    for n in neighbors(index, par_ranges):
        if n not in nodes:
            return True

    index_data[1] = False
    return False


def interpolate_indices(i1, i2, par_ranges):
    """Return the points in parameter space connecting two points."""
    if i1 == i2:
        return []
    value_indices = [range(len(r)) for r in par_ranges]
    # first convert index to multiindex where each component is the index
    #   into the set of parameter values
    v1 = index2point(i1, value_indices)
    v2 = index2point(i2, value_indices)
    # calculate the interpolation direction...
    delta = [v2[i] - v1[i] for i in range(len(par_ranges))]
    # ...and the coordinate direction in which we have the most steps
    # this will parametrize the line on parameter space grid
    longest_dir = max(range(len(par_ranges)), key=lambda i: abs(delta[i]))

    return [
        point2index(p, value_indices) for p in [
            [
                round(v1[i] + (delta[i] * 1.0 * n) / abs(delta[longest_dir]))
                for i in range(len(par_ranges))
            ]
            # take all n from 0 to N -> range(N+1)
            for n in range(abs(delta[longest_dir]) + 1)
        ]
    ]


def extrapolate_indices(i1, i2, par_ranges):
    """Extrapolate along the line defined by two points.

    That means for point x1 indexed by i1 and x2 indexed by i2
        Find the new point x3 = x1 + 2 (x2 - x1) and all points between
        x2 and x3
    """
    value_indices = [range(len(r)) for r in par_ranges]
    v1 = index2point(i1, value_indices)
    v2 = index2point(i2, value_indices)

    v3 = [
        max(0, min(len(par_ranges[i]) - 1, v1[i] + 2 * (v2[i] - v1[i])))
        for i in range(len(v1))
    ]

    return interpolate_indices(i2, point2index(v3, value_indices), par_ranges)
