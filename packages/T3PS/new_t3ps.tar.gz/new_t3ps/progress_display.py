#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 15:49:58 2022

@author: cb27g11
"""

# ---------------------------- #
# |  [D.03] Progress Display | #
# ---------------------------- #
# Progress Display functions for t3ps. Originally written by Vinzenz Maurer.

def terminal_size():
    """Determine terminal size as (width, height)."""
    if not sys.stdout.isatty():
        return (80, 24)

    height, width, _height_in_pixels, _width_in_pixels = struct.unpack(
        'HHHH',
        fcntl.ioctl(
            1,  # fd == 1 -> stdout
            termios.TIOCGWINSZ, struct.pack('HHHH', 0, 0, 0, 0)
        )
    )
    return width, height


def horizontal_line():
    """Print horizontal line spanning full width of terminal."""
    return "-" * terminal_size()[0]


def draw_progress(current, maximum, info="", width=None, abortable=True):
    """Draw progress bar to terminal with additional informational message.

    Also includes message if current action is abortable.
    """
    if not sys.stdout.isatty():
        # there's no use to show anything if there's no one looking
        return
    if not hasattr(draw_progress, "last_progress"):
        draw_progress.last_progress = None
        draw_progress.last_progress_time = time.time()
        draw_progress.last_info_length = 0
    # only draw once every 0.1 seconds or when we reached 100%
    elif time.time() - draw_progress.last_progress_time < 0.1 and \
            current < maximum:
        return

    draw_progress.last_progress_time = time.time()

    if width is None:
        width = terminal_size()[0]
    progress = current / (1.0 * maximum)

    # make display of current as long as maximum
    maximum = str(maximum)
    current = str(current).rjust(len(maximum))
    # and leave enough space for "100.00%" (7 chars)
    progress_info = "({}/{}) ~ {:>7.2%}".format(current, maximum, progress)
    # this way the bar never has to be resized

    # -2 for [], -1 for space between bar and info, -10 courtesy
    bar_length = width - 2 - 1 - len(progress_info) - 10

    num_segments = min(int(bar_length * progress), bar_length)
    wrapped_lines = []
    if info:
        for line in info.split("\n"):
            if len(line) <= width:
                wrapped_lines.append(line)
            else:
                wrapped_lines.extend(
                    textwrap.wrap(line, width=width, replace_whitespace=False)
                )
    wrapped_lines.append(
        "current scan: %s" % abbreviate_path(
            draw_progress.scan_file,
            width=width - len("current scan: ")
        )
    )
    if abortable:
        wrapped_lines.append("(press ctrl+c twice within 5 sec to abort)")

    wrapped_lines_length = len(wrapped_lines)
    wrapped_lines = "\n".join(wrapped_lines)

    if draw_progress.last_progress is None or \
       draw_progress.last_progress > progress or \
       draw_progress.last_max != maximum:
        # setup full progress bar space if there is no sufficient previous
        #   progress bar shown at the moment
        for _ in range(1 + wrapped_lines_length):
            print ""
    elif draw_progress.last_info_length < wrapped_lines_length:
        # only setup missing space
        for _ in range(wrapped_lines_length - draw_progress.last_info_length):
            print ""

    draw_progress.last_progress = progress
    draw_progress.last_max = maximum
    draw_progress.last_info_length = wrapped_lines_length

    for _ in range(1 + wrapped_lines_length):
        # this VT100 code causes the console cursor to go up one line
        sys.stdout.write("\x1B[1A")
        # this one clears the line
        sys.stdout.write("\x1B[K")

    # \r at the start of the line causes the new line to overwrite the old
    #   one (in a terminal)
    sys.stdout.write(
        "\r[%s%s] %s\n\r%s\n" % (
            "#" * num_segments,
            " " * (bar_length - num_segments),
            progress_info,
            wrapped_lines
        )
    )
    # if we are at the end, get rid of the abort message
    if progress == 1:
        for _ in range(2 if abortable else 1):
            sys.stdout.write("\x1B[1A")
            sys.stdout.write("\x1B[K")


def wait_for_user(message="continue"):
    """Wait for confirmation by the user (if stdin is interactive)."""
    if sys.stdin.isatty():
        try:
            raw_input("# Press enter to " + message)
        except (KeyboardInterrupt, EOFError):
            # interpret ctrl+d or ctrl+c as an immediate abort
            print  # print one last line for cosmetic purposes
            exit_program()


def times_to_rate_info(times, bunchsize):
    """Convert job completion times to job completion rates.

    bunchsize: jobs are done in batches of this size in parallel

    Returns the mean rate, its error and the minimal rate
    """
    # the first time is always the starting (=base) time
    if len(times) < bunchsize + 1:
        deltas = [float("nan")]
    else:
        # rate = N / time it took to calculate N items, where N is the bunch
        #   size (number of parallel computations)
        # we have to sum over at least that many, because otherwise the
        #   parallel nature will introduce very high rates due to points that
        #   were already finished while others were still written to file
        deltas = [
            (times[i + bunchsize] - times[i]) / bunchsize
            for i in range(len(times) - bunchsize)
        ]

    meandelta = mean(deltas)
    rate = 1 / meandelta
    rateerror = mean([
        abs(1 / meandelta - 1 / (meandelta + p * std(deltas)))
        for p in [-1., 1.]
    ])
    return rate, rateerror, max(rate - rateerror, 1 / max(deltas))


def progress_forecast(current, full, rate):
    """Return estimated completion time based on current progress and rate."""
    if not rate > 0:  # use this instead of <= to also catch nan's
        return "never"
    return time.ctime(time.time() + (full - current) / rate)


def abbreviate(s, width=30):
    """Abbreviate too long strings by replacing middle part with '...'."""
    if len(s) <= n:
        return s
    if n < 3:
        return ""
    if n < 5:
        return "..."
    return "%s...%s" % (
        s[0:int(n / 2 - 1)],
        s[int(-(n - n / 2 - 2)):]
    )


def abbreviate_path(path, width=30):
    """Abbreviate too long paths to (preferably unique) shortened ones.

    Uniqueness:
        /folder/file -> /f../file if not other folder starting with "f" exists
    """
    if len(path) <= width:
        return path
    if width < 3:
        return ""

    path = path.replace(os.path.expanduser("~"), "~")
    parts = path.split(os.sep)
    if not parts[0]:
        parts[0] = os.path.abspath(os.sep)

    shortened_parts = [parts[0]]
    for i, name in enumerate(parts[1:-1], start=1):
        parent = os.path.join(*parts[:i])
        siblings = os.listdir(os.path.expanduser(parent))
        for j in range(len(name)):
            shortened = name[:j + 1]
            if not any(sib.startswith(shortened) and
               sib != name for sib in siblings):
                shortened = shortened + ".."
                break
        shortened_parts.append(
            # only save shortened name if actually shorter
            shortened if len(shortened) < len(name) else name
        )
    shortened_parts.append(parts[-1])
    shortened_path = os.path.join(*shortened_parts)

    if len(shortened_path) == width:
        return shortened_path
    elif len(shortened_path) > width:
        for i in range(1, len(shortened_parts)):
            used_parts = ["..."] + shortened_parts[i:]
            shortened_path = os.path.join(*used_parts)
            if len(shortened_path) <= width:
                return shortened_path
        short_filename = abbreviate(parts[-1], width - 4)
        if short_filename in ["...", ""]:
            return "..."
        return ".../" + short_filename
    else:
        best_candidate = ""
        best_usedparts = []
        for k in range(len(shortened_parts) - 1):
            for subset in itertools.combinations(
                    range(len(shortened_parts)), k + 1
                    ):
                used_parts = []
                for i in range(len(shortened_parts)):
                    if i in subset:
                        used_parts.append(shortened_parts[i])
                    else:
                        used_parts.append(parts[i])
                candidate = os.path.join(*used_parts)
                L = len(candidate)
                L0 = len(best_candidate)
                if L <= width and (
                        L > L0 or
                        (L == L0 and max(used_parts) > max(best_usedparts))
                        ):
                    best_candidate = candidate
                    best_usedparts = used_parts
        return best_candidate


def mean(seq):
    """Calculate arithmetic mean of list of numbers."""
    return math.fsum(seq) / len(seq)


def std(seq):
    """Calculate standard deviation of list of numbers."""
    mu = mean(seq)
    return math.sqrt(mean([(x - mu) * (x - mu) for x in seq]))
