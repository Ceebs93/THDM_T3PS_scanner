#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 15:17:59 2022

@author: cb27g11
"""
# ---------------------------- #
# |  [D.10] Point Processing | #
# ---------------------------- #

#  Functions for t3ps explorer mode. Originally written by Vinzenz Maurer.

def process_item(point, test_mode=False, print_error_trace=False):
    """Process the point given by the values in <point>.

    Result is either a tuple (pars, vars, data) or an Exception (as an object)
    The exception error message is the first caught exception and most likely
        the first bound that is not satisfied.
    """
    print "Inside process_item"
    print "point is "
    print point
    # we get an already initialized point_processor from the main process
    #   through os.fork()
    global point_processor
    print "point_processor is "
    print point_processor
    # everything else is transferred via attributes of process_item

    (
        pars_with_names, vars_with_names, par_and_vars_with_names
    ) = process_item.with_names
    point = tuple(point)
    remember(None)

    result = Exception(point, "Unknown Error")
    # make a temporary directory in which we can run our item processor
    #   without any disturbances
    # keep the dir around if requested (i.e. in test mode)
    with TemporaryDirectory(keep_dir=test_mode) as tmpdir:
        if test_mode:
            print "# Working directory:", tmpdir
        with pushd(tmpdir):
            try:
                point_vars = []
                for formula in process_item.var_formulas:
                    point_vars.append(formula_eval(formula, pars=point))

                dressed_pars = pars_with_names(*point)
                dressed_vars = vars_with_names(*point_vars)
                dressed_both = par_and_vars_with_names(
                    *(tuple(point) + tuple(point_vars))
                )

                processed_template_file = None
                if process_item.template:
                    processed_template_file = os.path.join(tmpdir, "template")
                    with open(processed_template_file, "w") as \
                            processed_template:
                        processed_template.write(
                            eval(
                                process_item.template,
                                {
                                    "pars": dressed_pars,
                                    "vars": dressed_vars,
                                    "values": dressed_both
                                },
                                dressed_both._asdict()
                            )
                        )

                # if the processor takes more than one argument, it also
                #   expects pars and vars as namedtuples
                if point_processor and \
                   point_processor.main.func_code.co_argcount == 1:
                    processed_point = point_processor.main(
                        processed_template_file
                    )
                elif point_processor:
                    processed_point = point_processor.main(
                        processed_template_file,
                        dressed_pars,
                        dressed_vars
                    )
                else:
                    processed_point = []

                check_bounds(
                    process_item.bounds,
                    point, point_vars, processed_point
                )
# -- Below was previously commented out by David
                print('point', point)
                print('point_vars', point_vars)
                print('processed_point', processed_point)
#--------------------------------------------------------------

# - Warning - made a change here
                return (list(point), list(point_vars), list(processed_point))
#                return (list(processed_point))
                print "list(point)  ", list(point)
                print "list(point_vars   ", list(point_vars)
                print "processed_point   ", processed_point

            except Exception as e:
                if print_error_trace:
                    traceback.print_exc()
                # For FormulaError, only the first arg is relevant, since the
                #   second one is the point for which it was evaluated and we
                #   already have that at hand
                if isinstance(e, FormulaError):
                    e = Exception(e.args[0])

                # if the exception has an output attribute, it is probably
                #   and CalledProcessError, which is interesting for debugging
                if test_mode and hasattr(e, "output"):
                    print "# Error output:\n", e.output

                # make sure the error message stays in one column and line by
                #   replacing \t and \n
                msg = str(e).replace("\t", " ").replace("\n", " ")
                return Exception(point, msg)

    return result


def process_annotated_item(point_and_info):
    """Process point and keep track of info attached to it."""
    (point, info) = point_and_info
    data = process_item(point)
    print "info", info
    return (data, info)


def process_batch(batch):
    """Process multiple points at once."""
    print "-----------Entering process_batch now------------------"
    if not batch:
        print "I am not processing multiple points at once"
        return []
    # Sequence means it has __getitem__ and __len__, so batch[0][0] works
    if not isinstance(batch[0], Sequence):
        raise ValueError("Invalid batch")

    # if batch has structure [(Sequence, something), ...], each list item
    #   must have form (parameter_values, annotation)
    if isinstance(batch[0][0], Sequence):
        result = process_batch.pool.imap(
            process_annotated_item, batch
        )
    else:
        result = process_batch.pool.imap(process_item, batch)

    return result


class Bunch:

    """Object with a bunch of named attributes."""

    def __init__(self, **kwds):
        """Construct the object."""
        self.__dict__.update(kwds)

    config_in.__str__ = config_in.__repr__ = lambda self: 'Bunch(**%s)' % repr(dict(self.__dict__))


def process_batch_as_worker(batch):
    """Process multiple points and keep track of the progress."""
    if not batch:
        raise StopIteration()
    batch_length = len(batch)
    start_time = time.time()
    batch_id = hash(start_time)

    process_batch.running_batches[batch_id] = Bunch(
        current=0,
        full_length=batch_length,
        start_time_str=time.strftime("%d.%m.%Y %H:%M:%S"),
        start_time=start_time
    )
    log_msg("# Starting batch (id %s) of %i points" % (batch_id, batch_length))
    try:
        for i, x in enumerate(process_batch(batch)):
            process_batch.running_batches[batch_id].current = i + 1
            yield x
    finally:
        # the last iteration does not return after its yield, so use a
        #   try/finally block
        log_msg("# Finished batch (id %s)" % batch_id)


def check_bounds(bounds, pars, vars, data):
    """Check all bounds and raise ValueError if one is violated."""
    print "Now processing bounds..."
    for bound in bounds:
        allowed = formula_eval(
            bound,
            pars=pars,
            vars=vars,
            data=data
        )
        if not allowed:
            raise ValueError("point violates: %s" % bound)


def apply_symmetry(rule, point, par_names):
    """Apply symmetry to parameter point."""
    print "Now applying symmetry to parameter point..."
    transformed_point = list(point)
    replaced_values = formula_eval(
        rule,
        pars=transformed_point, **dict(zip(par_names, par_names))
    ).iteritems()
    print "replaced_values are " + replaced_values
    for k, v in replaced_values:
        if isinstance(k, int):
            transformed_point[k] = v
        elif isinstance(k, basestring):
            transformed_point[par_names.index(k)] = v

    return tuple(transformed_point)


def processing_concurrency():
    """Return local processing concurrency.

    This is used for weighting of worker processes.
    """
    return processing_concurrency.value
