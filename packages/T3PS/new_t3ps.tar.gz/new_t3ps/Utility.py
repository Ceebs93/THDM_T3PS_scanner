#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 15:23:39 2022

@author: cb27g11
"""
# ------------------- #
# |  [D.02] Utility | #
# ------------------- #
# Basic utility functions for t3ps. Originally written by Vinzenz Maurer.

def prod(iterable):
    """Analogue to sum function but for multiplication."""
    r = 1
    for x in iterable:
        r *= x
    return r


def list_sum(lists):
    """Concatenate lists together, similar to sum function."""
    # For reference (cannot use named argument):
    #   sum(items, start_value)
    return sum(lists, [])

def inverseerf(x, sqrt=math.sqrt, pi=math.pi, log=math.log, a=0.147):
    """Inverse erf function.

    Approximation taken from Winitzki, Sergei (6 February 2008)
    "A handy approximation for the error function and its inverse" (PDF).
    http://sites.google.com/site/winitzki/sergei-winitzkis-files/erf-approx.pdf
    This has relative precision better than 2e-3 for x in (-1, 1).
    """
    return math.copysign(
        sqrt(
            sqrt((2 / (pi * a) + log(1 - x * x) / 2) ** 2 - log(1 - x * x) / a)
            - (2 / (pi * a) + log(1 - x * x) / 2)
        ),
        x
    )


# thus this has accuracy 0.3%
def inversenormalcdf(p, sqrt=math.sqrt):
    """Inverse cumulative distribution function for std. normal distribution.

    Has about the same level of accuracy as the InverseCDF function in
    Wolfram Mathematica
    """
    return sqrt(2) * inverseerf(2 * p - 1)


def maybefloat(s):
    """Convert to float if possible, otherwise to string."""
    try:
        return float(s)
    except Exception:
        return str(s)


def maybedecimal(s):
    """Convert to Decimal if possible, otherwise to string."""
    try:
        return Decimal(s)
    except Exception:
        return str(s)


def is_number(s):
    """Check if string is valid decimal number."""
    try:
        Decimal(s)
        return True
    except decimal.InvalidOperation:
        return False
    except ValueError:
        return False


def print_table(names, values):
    """Print named values in nice table form to console."""
    def to_str(v):
        return repr(v) if isinstance(v, float) else str(v)

    max_data_length = max(max(len(to_str(x)) for x in values), 3)
    max_name_length = max(max(len(x) for x in names), 3)
    max_width = terminal_size()[0]

    # +3 for " | " and +2 for ": "
    headered_value_length = max_data_length + max_name_length + 3 + 2
    # a // b: integer division (rounds down)
    row_length = max(1, max_width // headered_value_length)

    padded_length = max(len(names), len(values))
    row_length = min(row_length, padded_length)
    if padded_length % row_length != 0:
        # print full rows
        padded_length += row_length - (padded_length % row_length)

    values = [to_str(v) for v in values]
    padded_data = list(pad_list(values, "---", padded_length))
    print "padded_data is ", padded_data
    padded_names = list(pad_list(names, "---", padded_length))
    print "padded_names are ", padded_names

    # There is
    #   ": "(2 chars) for each column -> weight row_length
    #   " | "(3 chars) between each column -> weight row_length-1
    hline = "-" * (
        (max_data_length + max_name_length) * row_length +
        2 * row_length +
        3 * (row_length - 1)
    )

    print hline
    # go from 0 to padded_length (exclusive) with step size row_length
    for i in range(0, padded_length, row_length):
        print " | ".join(
            padded_names[i + j].ljust(max_name_length) + ": " +
            padded_data[i + j].rjust(max_data_length)
            for j in range(row_length)
        )
    print hline


def split_by_comma(s):
    """Split by base level comma.

    That means not by comma inside brackets or strings.
    """
    # keep track in what string type we are in currently and what kind of
    #   brackets are open
    string_type = None
    brackets = [0, 0, 0]  # (), [], {}

    token = ""
    parts = []
    for c in s:
        if c == ',':
            # only split by lowest level commas that are not in strings
            if not any(brackets) and string_type is None:
                parts.append(token)
                token = ""
                continue
        elif c == string_type:
            string_type = None
        elif c in ("'", '"'):
            if string_type is None:
                string_type = c
        elif not string_type:
            if c == "(":
                brackets[0] += 1
            elif c == "[":
                brackets[1] += 1
            elif c == "{":
                brackets[2] += 1
            elif c == ")":
                brackets[0] -= 1
            elif c == "]":
                brackets[1] -= 1
            elif c == "}":
                brackets[2] -= 1
        token += c
    parts.append(token)
    return parts