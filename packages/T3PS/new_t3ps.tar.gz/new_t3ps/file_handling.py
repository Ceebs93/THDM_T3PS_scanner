#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 16:08:54 2022

@author: cb27g11
"""

# ---------------------- #
# |  [D.05] File Input | #
# ---------------------- #

# File input functions for t3ps. Originally written by Vinzenz Maurer.

def parspace_file_iterator(file_names):
    """Loop over lines in multiple files and return columns for each line.

    This ignores lines marked as invalid.
    """
    for file_name in file_names:
        print "filename", filename
        with open(file_name) as f:
            for line in f:
                p = map(U.maybefloat, line.strip().split("\t"))
                print "p is : ", p
                if p[0] == ERROR_MARKER:
                    continue
                yield p


def linecount(file_name):
    """Count lines in one or multiple files."""
    if type(file_name) == list:
        return sum(map(linecount, file_name))
    lines = 0
    try:
        if os.path.getsize(file_name) == 0:
            return 0
        # mmap seems to be the fastest way to do this and requires mode "r+"
        with open(file_name, "r+") as f:
            buf = mmap.mmap(f.fileno(), 0)
            print "------------inside linecount-------------------"
            rl = buf.readline
            while rl():
                lines += 1
    # ignore any errors regarding missing or unreadable files
    except IOError:
        pass
    except OSError:
        pass
    return lines


def get_columns(columns, row):
    """Extract the columns (given as list of formulas) from a given row."""
    p = []
    print "-----------inside get_columns-------------"
    for col in columns:
        print "col is: ", col
        p.append(
            float(formula_eval(col, file=row))
        )
    print p
    return p


def split_cols(cols, ns):
    """Split list into groups with lengths specified by ns.

    This drops anything after sum(ns) columns.
    """
    # if one ns[i] is inf (or NaN), all columns will be funneled into this
    #   one after ones before it are full
    print "-------------inside split_cols------------"
    
    r = [[] for _ in ns]
    i = 0
    for col in cols:
        # use while to skip over ns[i] that are 0
        while len(r[i]) >= ns[i]:
            i += 1

        if i >= len(ns):
            return r

        r[i].append(col)

    print r
    return r


def out_repr(x):
    """Convert value to its representation in output files."""

    if isinstance(x, basestring):
        return x.replace("\t", " ").replace("\n", " ")
    return repr(x)