#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 15:07:09 2022

@author: cb27g11
"""
# ---------------------------------------------- #
# |  [D.08] Markov Chain Monte Carlo Functions | #
# ---------------------------------------------- #

#  Functions for MCMC generation for t3ps. Originally written by Vinzenz Maurer.

class ProbabilityError(ValueError):

    """Custom exception for the Metropolis-Hastings algorithm.

    Signals that a candidate point has vanishing likelihood
    """

    pass


def allowed_by_prior(x, par_ranges):
    """Check whether given point has non-zero prior likelihood."""
    print "                                 " 
    print "----------------------- Inside 'allowed_by_prior'---------------------------------- "
    print "                                 "
    for i, r in enumerate(par_ranges):
        print " i and r in enumerate(par_ranges) are: "
        print(i , r)
        print " x[i] is : "
        print x[i]
        if x[i] not in r:
            return False
    return True


def prior_likelihood(x, par_ranges):
    """Calculate prior likelihood for given point and parameter ranges."""
    p = 1
    print "                                           "
    print "---------------------------------Inside 'prior likelihood-----------------------------"
    print "Initial prior is :", p
    print "x is ", x
    print "par_ranges is ", par_ranges
    for i, r in enumerate(par_ranges):
        # contained check also works for continuous ranges
        if x[i] not in r:
            p = 0
            print "x[i] is not in r"
            print x[i], r
            break

        config_in.values = r.config_in.values
        if isinstance(config_in.values, ParameterRange_Interval):
            print "Hooray the value is in the parameterrange!"
            dist = r.config_in.options["distribution"]
            if dist == "linear":
                pass  # p *= 1
            elif dist == "log":
                # dp = C dlogx = C 1/x * dx
                p *= 1 / abs(x[i])
                print "Updated prior is: ", p
            else:
                raise ValueError("unsupported distribution type: " + str(dist))
        elif isinstance(config_in.values, ParameterRange_NormalVariate):
            p *= math.exp(-0.5 * ((x[i] - config_in.values.mu) / config_in.values.sigma) ** 2)
            print "mu value is ", config_in.values.mu
            print "sigma value is ", config_in.values.sigma
            print "                                                 "
            print "Updated prior is : ", p
        elif isinstance(config_in.values, tuple):
            # finite -> Laplace probability (all equal)
            pass  # p *= 1
        else:
            raise ValueError(
                "unsupported distribution type: " + str(type(config_in.values))
            )
    print "End of func prior_likelihood, final prior value is: ", p
    return p


def mcmc_step(theta0, par_ranges):
    """Make one iteration "step".

    That means: return new point theta, obtained from proposal probability
        density q(theta, theta0) around theta0, together with the value
        of q(theta, theta0) and q(theta0, theta)
    """
    print "                                  "
    print "-----------------------------Inside mcmc_step-----------------------      "
    print " Value for theta0 is: "
    print theta0
    print "                          "
    theta, q, q0 = [], 1, 1
    append = theta.append
    randomnormalvariate = random.normalvariate
    for i, r in enumerate(par_ranges):
        if "mcmc_stepsize" in r.config_in.options:
            print "I have found the mcmc_stepsize"
            # standard Gaussian stepsize -> symmetric
            # is always canceled in Hastings test ratio
            # q *= 1
            # q0 *= 1
            if r.config_in.is_finite:
                # if there are infinite indices, q(i1,i0) is symmetric
                i0 = r.index(theta0[i])
                i1 = int(round(
                    randomnormalvariate(i0, r.config_in.options["mcmc_stepsize"])
                ))

                # however, if we go out of bounds on the new index, the
                #   implicit prior on the interval [0, len(r.values)] takes
                #   effect and rules out the point
                # raising an exception to the MH algorithm correctly handles
                #   this
                if i1 < 0 or len(r) <= i1:
                    raise ProbabilityError("out of finite bounds")
                append(r.config_in.values[i1])
                print "                                "
                print " Have appended new value to r "
                print "Value of r is  ", r
            else:
                append(
                    randomnormalvariate(theta0[i], r.config_in.options["mcmc_stepsize"])
                )
                print "                                  "
                print " Have appended new value to r "
                print "Value of r is  ", r
        else:
            # take from prior density -> not-symmetric but well known
            print "                                  "
            print " taking value from prior density"
            x = rdm.make_random_point([r])[0]
            print "x is a new random point: ", x
            q *= prior_likelihood([x], [r])
            print "The prior likelihood, (for x) for r is: ", q
            q0 *= prior_likelihood([theta0[i]], [r])
            print "The prior likelihood, (for theta0), for r is: ", q0
            append(x)

        print "                                      "
        print "theta, q and q0 have values of", theta, q, q0

    return (theta, q, q0)


def make_chain(data):
    """Standard (Metropolis-)Hastings algorithm to calculate a MCMC sample.

    Algorithm correspondence:
        p(theta) = likelihood(theta) * prior(theta) * has_errors(theta)
        q(theta, theta0) = separable into densities for one coordinate each:
            if mcmc_stepsize defined:
                normalvariate around theta0 = f( (theta-theta0)_i^2 )
                -> symmetric
            else:
                q(theta, theta0) = prior(theta) -> not symmetric
                q(theta, theta0) and q(theta0, theta) are returned by mcmc_step
    """
    (
        output_file, rejected_file, x0, current_length, final_length,
        par_ranges, current_iteration, likelihood_code, heating_function_code,
        status_file_path, debug_mode, random_seed
    ) = data

    print "data   ", data

    #print "heating_function_code is: ", heating_function_code

    def likelihood(x, code=likelihood_code):
        print " ----Inside 'make_chain: def likelihood'-----"
        print "                                          "
        print "code is ", code
        print "pars=x[0] is ", x[0]
        print "vars=x[1] is ", x[1]
        print "data=x[2] is ", x[2]
        print formula_eval(code, pars=x[0], vars=x[1], data=x[2])

        return formula_eval(code, pars=x[0], vars=x[1], data=x[2])

    if heating_function_code:
        def heating_function(iteration, dlogL, logL0):
            print "iteration ", iteration
            print " dlogL  ", dlogL
            print "logL0  ", logL0
           
            print "formula_eval(stuff) ", formula_eval(
                heating_function_code,
                iteration=iteration,
                dlogL=dlogL,
                logL0=logL0
            )


            return formula_eval(
                heating_function_code,
                iteration=iteration,
                dlogL=dlogL,
                logL0=logL0
            )
            print "----Inside 'make_chain: def heating_function_code'------------"
            print "                                                  "
    else:
        heating_function = None

    L0 = likelihood(x0) * prior_likelihood(x0[0], par_ranges)
    print likelihood(x0), "*", prior_likelihood(x0[0], par_ranges)
    print "L0 -> likelihood(x0) * prior(x0, par_ranges)"
    print "L0 " + str(L0)
    print "prior_likelihood "
    print prior_likelihood(x0[0], par_ranges)
    # IMPORTANT: re-seed PRNG so all chains are guaranteed to find distinct
    #   points - THIS HAS TO BE DIFFERENT FOR EACH CHAIN
    random.seed(random_seed)
    print "random.seed is ", random.seed(random_seed)
    staycount = 0
    # we keep track of all errors and reasons why points get discarded
    #   this resets when new point is found and is only ever shown in expert
    #   mode
    reasons = {"prior": 0, "likelihood": 0, "errors": 0, "chance": 0}
    print " Reasons for error: ", reasons
    
    try:
        while current_length < final_length:
            print "current_length is ", current_length
            with open(status_file_path, "w") as status_file:
                pickle.dump([
                    current_length,
                    current_iteration,
                    reasons
                ], status_file)

            current_iteration += 1
            alpha = 0
            try:
                # x0[0] because x is (pars, vars, data)
                print "x0[0] is ", x0[0]
                x1, q1, q0 = mcmc_step(x0[0], par_ranges)
                print " x1, q1, q0 are as follows "
                print( x1, q1, q0)
                if not allowed_by_prior(x1, par_ranges):
                    print " values are not allowed by prior "
                    x1 = Exception(x1, "excluded by prior = 0")
                    reasons["prior"] += 1
                    staycount += 1
                    raise ProbabilityError("point excluded by prior = 0")
                x1 = process_item(x1)
                print("x1 is: ", x1 )

                if isinstance(x1, Exception):
                    print Exception
                    reasons["errors"] += 1
                    staycount += 1
                    raise ProbabilityError("point excluded by processor error")

                L1 = likelihood(x1) * prior_likelihood(x1[0], par_ranges)
                print("L1", L1)
                if L1 <= 0:
                    reasons["likelihood"] += 1
                    staycount += 1
                    raise ProbabilityError("point excluded by likelihood = 0")

            except ProbabilityError as e:
                # all other errors are not recoverable and break the chain
                #   immediately
                L1 = 0

            else:  # executed if try block was finished without exception
                # Hastings testing ratio
                #        p(theta)  q(theta0, theta)
                # min(1, -------------------------- )
                #        p(theta0) q(theta, theta0)
                print "heating_function: ", heating_function
                alpha = min(
                    1,
                    (
                        L1 / L0 if heating_function is None else math.exp(
                            heating_function(
                                current_iteration,
                                math.log(L1 / L0),
                                math.log(L0)
                            )
                        )
                    ) * q0 / q1
                )
                print " alpha value is:", alpha
            if random.random() < alpha:
                with open(output_file, "a") as f:
                    f.write(
                        "\t".join(
                            map(FH.out_repr, U.list_sum(x0) + [L0, staycount])
                        )
                    )
                    f.write("\n")
                    print "U.list_sum(x0), L0 and staycount are: "
                    print U.list_sum(x0), L0, staycount
                x0 = x1
                L0 = L1
                staycount = 1
                current_length += 1
                reasons = {
                    "prior": 0, "likelihood": 0, "errors": 0, "chance": 0
                }
            else:
# Warning/WARNING/
#               if not isinstance(x1, Exception):
#                   with open(rejected_file, "a") as f:
#                       f.write("\t".join(map(out_repr, U.list_sum(x1) + [L1])))
#                       f.write("\n")

                staycount += 1
                if alpha > 0:
                    reasons["chance"] += 1

        # write the last point to file
        with open(output_file, "a") as f:
            f.write("\t".join(map(FH.out_repr, U.list_sum(x0) + [L0, staycount])))
            f.write("\n")
        # and write the 100% status, too
        with open(status_file_path, "w") as status_file:
            pickle.dump([
                current_length,
                current_iteration,
                reasons
            ], status_file)

    except Exception as e:
        if debug_mode:
            traceback.print_exc()
        raise Exception("Chain ended by error: " + str(e))

    return "Chain done in file %r" % file
    # nobody will ever read this return value anyway
