#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 15:04:14 2022

@author: cb27g11
"""

# ---------------------- #
# |  [D.07] Randomness | #
# ---------------------- #

#  Functions to handle random generation for t3ps. Originally written by Vinzenz Maurer.

def scatter_iterator(count, par_ranges):
    """Yield a given number of random points in the given parameter ranges."""
    for _ in xrange(count):
        yield make_random_point(par_ranges)


def make_random_point(par_ranges):
    """Return random point with the distribution of the parameter ranges."""

    # If we need to generate a random string to use to indentify datafiles for the C++
    # code to output to this may be a good place to do so. It could be added to the
    # "point" and then just directly read in by both the python processor and the C++
    # file - Ciara

    print "Generating a random point now..."
    point = []
    # increase speed by minimizing the amount of look-ups
    append = point.append
    randomuniform = random.uniform
    randomnormalvariate = random.normalvariate
    randomchoice = random.choice

    for r in par_ranges:
        config_in.values = r.values
        # if parameter range is continuous, return new point with appropriate
        #   distribution
        if not r.config_in.is_finite:
            if isinstance(values, ParameterRange_Interval):
                dist = r.config_in.options.get("distribution", "linear")
                if dist == "linear":
                    append(randomuniform(config_in.values.start, config_in.values.end))
                elif dist == "log":
                    append(
                        math.exp(
                            randomuniform(
                                math.log(config_in.values.start),
                                math.log(config_in.values.end)
                            )
                        )
                    )
                else:
                    raise ValueError("unsupported distribution type: " + dist)
            elif isinstance(config_in.values, ParameterRange_NormalVariate):
                append(randomnormalvariate(config_in.values.mu, config_in.values.sigma))
            else:
                raise ValueError(
                    "unsupported distribution type: " + str(type(config_in.values))
                )
        # otherwise jump randomly in discrete list with appropriate step size
        else:
            append(randomchoice(config_in.values))

    return point
