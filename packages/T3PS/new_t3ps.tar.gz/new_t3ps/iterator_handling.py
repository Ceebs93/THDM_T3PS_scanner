#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 16:01:06 2022

@author: cb27g11
"""

import itertools

# ----------------------------- #
# |  [D.04] Iterator Handling | #
# ----------------------------- #
# Iterator Handling functions for t3ps. Originally written by Vinzenz Maurer.

def it_len(iterable):
    """Count elements in an iterator.

    Warning: this consumes the iterator entirely
    """
    c = 0
    for _ in iterable:
        c += 1
    return c


def first(iterable):
    """Return the first element in an iterator."""
    for x in iterable:
        return x


def take(n, iterable):
    """Take n items out of an iterable, starting from the current position."""
    return list(itertools.islice(iterable, n))


def consume(n, iterator):
    """Consume the first n elements in an iterator."""
    # Take the slice starting at position n and consume those before it by
    #   advancing blindly
    next(itertools.islice(iterator, n, n), None)


def roundrobin(*iterables):
    """Return list obtained from interleaving the lists in iterables.

    Example: roundrobin("aaaa", "bbb", "cc") -> a b c a b c a b a a

    Note: this assumes that None is not in any of the iterables
        (satisfied in our use case)
    """
    for xs in itertools.izip_longest(*iterables, fillvalue=None):
        for x in xs:
            if x is not None:
                yield x


def pad_list(iterable, padding, length):
    """Pad list to specified length with padding value."""
    i = -1
    for i, x in enumerate(iterable):
        yield x
    # i + 1 is now length of iterable
    while i + 1 < length:
        yield padding
        i += 1
